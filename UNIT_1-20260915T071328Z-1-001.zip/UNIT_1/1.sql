DECLARE
 str varchar2(100):='&name';

BEGIN 
 
  dbms_output.put_line(str);

END;
/